import React, { useState } from 'react';
import { Header } from './components/Header';
import { NoteInput } from './components/NoteInput';
import { NoteList } from './components/NoteList';
import { Note } from './types/Note';

function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [inputText, setInputText] = useState('');

  const addNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      setNotes([...notes, { id: Date.now().toString(), text: inputText, completed: false }]);
      setInputText('');
    }
  };

  const toggleNote = (id: string) => {
    setNotes(notes.map(note =>
      note.id === id ? { ...note, completed: !note.completed } : note
    ));
  };

  const activeNotes = notes.filter(note => !note.completed);
  const completedNotes = notes.filter(note => note.completed);

  return (
    <div className="min-h-screen bg-[#FFF8F0] p-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <Header />
          <NoteInput
            inputText={inputText}
            setInputText={setInputText}
            addNote={addNote}
          />
          <NoteList notes={activeNotes} onToggle={toggleNote} />
          <NoteList
            title="Completed Notes"
            notes={completedNotes}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
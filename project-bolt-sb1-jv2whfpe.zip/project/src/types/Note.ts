export interface Note {
  id: string;
  text: string;
  completed: boolean;
}
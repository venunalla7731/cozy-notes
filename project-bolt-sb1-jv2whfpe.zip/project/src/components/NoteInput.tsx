import React from 'react';
import { PlusCircle } from 'lucide-react';

interface NoteInputProps {
  inputText: string;
  setInputText: (text: string) => void;
  addNote: (e: React.FormEvent) => void;
}

export function NoteInput({ inputText, setInputText, addNote }: NoteInputProps) {
  return (
    <form onSubmit={addNote} className="mb-6">
      <div className="flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Add a new note..."
          className="flex-1 px-4 py-2 rounded-lg border border-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-amber-50"
        />
        <button
          type="submit"
          className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center gap-2"
        >
          <PlusCircle className="w-5 h-5" />
          Add
        </button>
      </div>
    </form>
  );
}
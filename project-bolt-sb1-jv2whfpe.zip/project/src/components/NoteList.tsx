import React from 'react';
import { NoteItem } from './NoteItem';
import { Note } from '../types/Note';

interface NoteListProps {
  title?: string;
  notes: Note[];
  onToggle?: (id: string) => void;
}

export function NoteList({ title, notes, onToggle }: NoteListProps) {
  if (notes.length === 0) return null;

  return (
    <div className={title ? 'mt-8' : ''}>
      {title && (
        <h2 className="text-xl font-semibold text-amber-800 mb-4">{title}</h2>
      )}
      <div className="space-y-3">
        {notes.map(note => (
          <NoteItem key={note.id} note={note} onToggle={onToggle} />
        ))}
      </div>
    </div>
  );
}
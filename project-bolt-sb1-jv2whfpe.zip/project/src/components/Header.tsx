import React from 'react';
import { Coffee } from 'lucide-react';

export function Header() {
  return (
    <div className="flex items-center justify-center mb-6">
      <Coffee className="w-8 h-8 text-amber-600 mr-2" />
      <h1 className="text-3xl font-bold text-amber-800">Cozy Notes</h1>
    </div>
  );
}
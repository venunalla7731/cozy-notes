import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Note } from '../types/Note';

interface NoteItemProps {
  note: Note;
  onToggle?: (id: string) => void;
}

export function NoteItem({ note, onToggle }: NoteItemProps) {
  if (note.completed) {
    return (
      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg text-gray-500 line-through">
        <CheckCircle2 className="w-6 h-6 text-green-500" />
        <span className="flex-1">{note.text}</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg hover:bg-amber-100 transition-colors">
      <button
        onClick={() => onToggle?.(note.id)}
        className="text-amber-600 hover:text-amber-800 transition-colors"
      >
        <CheckCircle2 className="w-6 h-6" />
      </button>
      <span className="flex-1">{note.text}</span>
    </div>
  );
}